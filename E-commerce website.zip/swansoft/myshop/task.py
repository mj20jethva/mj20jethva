from celery import shared_task
from django.core.mail import send_mail



@shared_task
def send_mail_registration():
    send_mail('Registered - The Karma Shop',"You are Registerd on our Site, Thank you for Registration",
        "jethvamohit26@gmail.com",
        ['jethvamohit26@gmail.com'],
        fail_silently=False)
    return None

@shared_task
def send_mail_checkout():
    send_mail('Order Placed - The Karma Shop',"Thank you for Purchasing with us. Use Tracker to Know further information",
        "jethvamohit26@gmail.com",
        ['jethvamohit26@gmail.com'],
        fail_silently=False)
    return None