from django.shortcuts import render,redirect
from django.contrib import messages
from django.views import View
from django.contrib.auth.models import User, auth
from django.core.mail import send_mail
from django.conf import settings
from .models import Product, Orders, OrderUpdate
import json
from django.http import HttpResponse
from .task import *



# Create your views here.

class IndexView(View):

    det = Product.objects.all()
    def get(self,request):
        return render(request, 'index.html', {'det':self.det})

class LoginView(View):
    def post(self,request):
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request, user)
            return redirect("/")
        else:
            messages.info(request,'invalid credentials')
            return redirect('login')
        return render(request, 'login.html')

    def get(self,request):
        return render(request,'login.html')

class LogoutView(View):
    def get(self,request):
        auth.logout(request)
        return redirect('/')


class RegistrationView(View):
    def post(self,request):
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']

        if password1==password2:
            if User.objects.filter(username=username).exists():
                messages.info(request,'Username Taken')
                return redirect('registration')
            elif User.objects.filter(email=email).exists():
                messages.info(request,'Email Taken')
                return redirect('registration')
            else:
                user = User.objects.create_user(username=username, password=password1, email=email, first_name=first_name, last_name=last_name)
                user.save()
                send_mail_registration()
                return redirect('login')
        else:
            messages.info(request,'password not matching...')
            return redirect('registration')
        return redirect('/')  

    def get(self,request):
        return render(request,'registration.html')

class ContactView(View):
    def get(self,request):
        return render(request, 'contact.html')

class CheckoutView(View):
    def post(self,request):
        items_json= request.POST.get('itemsJson', '')
        name=request.POST.get('name', '')
        email=request.POST.get('email', '')
        address=request.POST.get('address1', '') + " " + request.POST.get('address2', '')
        city=request.POST.get('city', '')
        state=request.POST.get('state', '')
        zip_code=request.POST.get('zip_code', '')
        phone=request.POST.get('phone', '')

        order = Orders(items_json= items_json, name=name, email=email, address= address, city=city, state=state, zip_code=zip_code, phone=phone)
        order.save()
        send_mail_checkout()
        update= OrderUpdate(order_id= order.order_id, update_desc="The order has been placed")
        update.save()
        thank=True
        id=order.order_id
        return render(request, 'checkout.html', {'thank':thank, 'id':id})

    def get(self,request):
        return render(request,'checkout.html')

class CartView(View):
    def get(self,request):
        return render(request, 'cart.html')

class TrackingView(View):
    def post(self,request):
        orderId = request.POST.get('orderId', '')
        email = request.POST.get('email', '')
        try:
            order = Orders.objects.filter(order_id = orderId, email = email)
            if len(order)>0:
                update = OrderUpdate.objects.filter(order_id=orderId)
                updates = []
                for item in update:
                    updates.append({'text':item.update_desc,'time':item.timestamp})
                    response = json.dumps(updates, default=str)
                return HttpResponse(response)
            else:
                return HttpResponse('{}')
        except Exception as e:
            return HttpResponse('{}')
        return render(request, 'tracking.html')

    def get(self,request):
        return render(request,'tracking.html')

class ProdView(View):
    def get(self,request, myid):
        # Fetch the product using the id 
        product = Product.objects.filter(id=myid)
        return render(request, 'prodView.html', {'product':product[0]})
