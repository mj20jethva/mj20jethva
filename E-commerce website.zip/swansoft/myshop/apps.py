from django.apps import AppConfig


class MyshopConfig(AppConfig):
    name = 'myshop'
